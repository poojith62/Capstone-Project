import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Services
import { AddressService } from './services/address.service';
import { AssessmentService } from './services/assessment.service';
import { BatteryService } from './services/battery.service';
import { BatteryHealthService } from './services/battery-health.service';
import { ChargingProfileService } from './services/charging-profile.service';
import { ClaimService } from './services/claim.service';
import { CustomerService } from './services/customer.service';
import { EvProfileService } from './services/ev-profile.service';
import { PolicyService } from './services/policy.service';
import { QuoteService } from './services/quote.service';
import { RenewalService } from './services/renewal.service';
import { TelematicsProfileService } from './services/telematics-profile.service';
import { UnderwritingService } from './services/underwriting.service';
import { VehicleService } from './services/vehicle.service';
import { AuthService, UserRole } from './services/auth.service';
import { MockDataService } from './services/mock-data.service';

// Models
import { AddressType } from './Models/Address/address-type.enum';
import { CreateAddressRequest } from './Models/Address/create-address-request.model';
import { ClaimStatus } from './Models/Claims/claim-status.enum';
import { CreateClaimRequest } from './Models/Claims/create-claim-request.model';
import { CreateQuoteRequest } from './Models/quotes/create-quote-request.model';
import { CreateVehicleRequest } from './Models/Vehicle/vehicles/create-vehicle-request.model';
import { EmployeeRegistrationRequest } from './Models/Auth/employee-registration-request.model';

export type AppView =
  | 'home'
  | 'auth'
  | 'c-dash'
  | 'c-veh'
  | 'c-quotes'
  | 'c-pol'
  | 'c-claims'
  | 'c-prof'
  | 'u-cases'
  | 's-queue'
  | 's-assess'
  | 'a-req';

export type AuthMode = 'login' | 'register' | 'apply' | 'forgot' | 'reset';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {
  // Injected Services
  readonly addressService = inject(AddressService);
  readonly assessmentService = inject(AssessmentService);
  readonly batteryService = inject(BatteryService);
  readonly batteryHealthService = inject(BatteryHealthService);
  readonly chargingProfileService = inject(ChargingProfileService);
  readonly claimService = inject(ClaimService);
  readonly customerService = inject(CustomerService);
  readonly evProfileService = inject(EvProfileService);
  readonly policyService = inject(PolicyService);
  readonly quoteService = inject(QuoteService);
  readonly renewalService = inject(RenewalService);
  readonly telematicsProfileService = inject(TelematicsProfileService);
  readonly underwritingService = inject(UnderwritingService);
  readonly vehicleService = inject(VehicleService);
  readonly authService = inject(AuthService);
  readonly mockData = inject(MockDataService);

  // App State
  readonly currentView = signal<AppView>('home');
  readonly authMode = signal<AuthMode>('login');
  readonly currentRole = computed(() => this.authService.currentRole());
  readonly sidebarCollapsed = signal(false);
  readonly mobileSidebarOpen = signal(false);

  // Toast
  readonly toastMessage = signal<string | null>(null);
  private toastTimer: any = null;

  // Confirm Modal
  readonly confirmModalOpen = signal(false);
  readonly confirmModalText = signal('');
  private confirmAction: (() => void) | null = null;

  // Modals for adding items
  readonly addVehicleModalOpen = signal(false);
  readonly addAddressModalOpen = signal(false);

  // Vehicle Active Tab
  readonly vehicleTab = signal<'Overview' | 'Battery' | 'Charging' | 'EV profile' | 'Telematics'>('Overview');
  // Profile Active Tab
  readonly profileTab = signal<'Details' | 'Addresses' | 'Documents'>('Details');

  // Auth Form Fields
  authForm = {
    fullName: '',
    email: 'customer@gmail.com',
    password: '••••••••',
    phone: '+91 90000 00000',
    role: 'Underwriter' as 'Underwriter' | 'Surveyor',
    token: ''
  };

  // Quick Quote Form
  quickQuote = {
    type: 'Electric vehicle',
    mobile: ''
  };

  // New Quote Form
  newQuote = {
    vehicleId: 'veh-1',
    vehicleModel: 'Tata Nexon EV',
    coverType: 'Comprehensive',
    vehicleValue: 1450000,
    policyTermMonths: 12
  };

  // Raise Claim Form
  newClaim = {
    policyId: 'EV-90112',
    incidentDate: new Date().toISOString().substring(0, 10),
    incidentDescription: '',
    estimatedLossAmount: 1500
  };

  // Add Vehicle Form
  newVehicleForm: CreateVehicleRequest = {
    vin: '',
    registrationNumber: '',
    manufacturer: 'Tata',
    model: 'Nexon EV',
    manufactureYear: 2024
  };

  // Add Address Form
  newAddressForm: CreateAddressRequest = {
    AddressLine1: '',
    AddressLine2: '',
    City: 'Hyderabad',
    State: 'Telangana',
    PostalCode: '500034',
    Country: 'India',
    AddressType: AddressType.Residential,
    IsPrimary: true
  };

  // Underwriting Selected Case
  selectedCase = signal<any | null>(null);
  loadingPercentage = signal(5);
  underwritingNotes = signal('');

  // Surveyor Selected Claim Assessment
  assessingClaim = signal<any | null>(null);
  assessmentDecision = signal<'Approved' | 'Rejected'>('Approved');
  assessmentAmount = signal(1200);
  assessmentRemarks = signal('Damage verified on site. Approved sensor replacement.');

  // Vehicle sub-forms
  batteryForm = {
    StateOfHealth: 84,
    RatedCapacityKwh: 40.5,
    CurrentCapacityKwh: 34.02,
    CycleCount: 420,
    BatteryAgeMonths: 18,
    Status: 2
  };

  chargingForm = {
    homeChargingPercentage: 75,
    publicChargingPercentage: 15,
    fastChargingPercentage: 10
  };

  evProfileForm = {
    BatteryCapacityKwh: 40.5,
    RangeKm: 312,
    MotorPowerKw: 105,
    MaxChargingSpeedKw: 50,
    BatteryChemistry: 'Li-ion NMC',
    DriveType: 'FWD'
  };

  telematicsForm = {
    totalDistanceKm: 24800,
    averageDailyDistanceKm: 38.3,
    efficiencyKmPerKwh: 7.7
  };

  // Customer Profile Form
  customerProfileForm = {
    firstName: 'Poojith',
    lastName: 'Kumar',
    email: 'poojith@evsure.com',
    phoneNumber: '+91 90000 00000'
  };

  // Cover Types on Landing Page
  readonly coverTypes = [
    { icon: '🚗', title: 'Electric & Motor', desc: 'EV and car cover with battery-aware pricing.', active: true },
    { icon: '❤️', title: 'Health', desc: 'Hospital and wellness cover for you and family.', active: false },
    { icon: '🛡', title: 'Life', desc: 'Financial security for the people you love.', active: false },
    { icon: '🏠', title: 'Home', desc: 'Protect your property and belongings.', active: false },
    { icon: '✈️', title: 'Travel', desc: 'Trips covered at home and abroad.', active: false },
    { icon: '💼', title: 'Business', desc: 'Cover for shops, offices and fleets.', active: false }
  ];

  // Steps on Landing Page
  readonly steps = [
    { num: 1, title: 'Register', desc: 'Create your profile and add what you want to insure.' },
    { num: 2, title: 'Get a quote', desc: 'A risk-based premium in seconds.' },
    { num: 3, title: 'Underwriter review', desc: 'Experts approve and your policy is issued.' },
    { num: 4, title: 'Claim with ease', desc: 'A surveyor assesses and decides, and you track it online.' }
  ];

  // Reactive data derived from MockDataService (synced with HTTP calls)
  readonly quotes = computed(() => this.mockData.quotes());
  readonly policies = computed(() => this.mockData.policies());
  readonly claims = computed(() => this.mockData.claims());
  readonly vehicles = computed(() => this.mockData.vehicles());
  readonly addresses = computed(() => this.mockData.addresses());
  readonly documents = computed(() => this.mockData.documents());
  readonly underwritingCases = computed(() => this.mockData.underwritingCases());
  readonly employeeRequests = computed(() => this.mockData.employeeRequests());

  // KPIs
  readonly kpiVehicles = computed(() => this.vehicles().length);
  readonly kpiPolicies = computed(() => this.policies().length);
  readonly kpiClaims = computed(() => this.claims().filter(c => c.status !== ClaimStatus.Closed && c.status !== ClaimStatus.Settled).length);
  readonly kpiQuotes = computed(() => this.quotes().filter(q => q.status === 'Pending' || q.status === 'Approved').length);

  ngOnInit(): void {
    // Select first underwriting case by default if available
    if (this.underwritingCases().length > 0) {
      this.selectedCase.set(this.underwritingCases()[0]);
    }
  }

  // Navigation
  goToView(view: AppView): void {
    this.currentView.set(view);
    this.mobileSidebarOpen.set(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  toggleSidebar(): void {
    if (window.innerWidth >= 768) {
      this.sidebarCollapsed.update(v => !v);
    } else {
      this.mobileSidebarOpen.update(v => !v);
    }
  }

  // Toast notification
  showToast(message: string): void {
    this.toastMessage.set(message);
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => {
      this.toastMessage.set(null);
    }, 2800);
  }

  // Confirm Modal
  askConfirm(message: string, onConfirm: () => void): void {
    this.confirmModalText.set(message);
    this.confirmAction = onConfirm;
    this.confirmModalOpen.set(true);
  }

  confirmOk(): void {
    this.confirmModalOpen.set(false);
    if (this.confirmAction) {
      this.confirmAction();
      this.confirmAction = null;
    }
  }

  confirmCancel(): void {
    this.confirmModalOpen.set(false);
    this.confirmAction = null;
  }

  // Auth Operations
  openAuth(mode: AuthMode): void {
    this.authMode.set(mode);
    if (mode === 'login') {
      this.authForm.email = 'customer@gmail.com';
    } else if (mode === 'apply') {
      this.authForm.email = 'staff@evsure.com';
      this.authForm.role = 'Underwriter';
    }
    this.goToView('auth');
  }

  enterRole(role: UserRole): void {
    this.authService.setRole(role);
    if (role === 'Customer') {
      this.goToView('c-dash');
    } else if (role === 'Underwriter') {
      this.goToView('u-cases');
      if (this.underwritingCases().length > 0) {
        this.selectedCase.set(this.underwritingCases()[0]);
      }
    } else if (role === 'Surveyor') {
      this.goToView('s-queue');
    } else if (role === 'Admin') {
      this.goToView('a-req');
    }
    this.showToast(`Signed in as ${role}`);
  }

  submitAuth(): void {
    const mode = this.authMode();
    if (mode === 'login') {
      this.authService.login({ email: this.authForm.email, password: this.authForm.password }).subscribe({
        next: () => {
          this.enterRole(this.currentRole());
        },
        error: () => {
          this.enterRole(this.currentRole());
        }
      });
    } else if (mode === 'register') {
      this.authService.register({
        email: this.authForm.email,
        password: this.authForm.password,
        fullName: this.authForm.fullName,
        phone: this.authForm.phone
      }).subscribe({
        next: () => {
          this.showToast('Account registered successfully');
          this.openAuth('login');
        },
        error: () => {
          this.showToast('Account registered');
          this.openAuth('login');
        }
      });
    } else if (mode === 'apply') {
      const typeId = this.authForm.role === 'Underwriter' ? 2 : 3;
      const req: EmployeeRegistrationRequest = {
        fullName: this.authForm.fullName || 'Candidate User',
        email: this.authForm.email,
        phoneNumber: this.authForm.phone,
        password: this.authForm.password,
        employeeTypeId: typeId
      };
      this.authService.employeeRegister(req).subscribe({
        next: () => {
          this.showToast('Employee application submitted for Admin approval');
          this.goToView('home');
        },
        error: () => {
          this.showToast('Application submitted for Admin review');
          this.goToView('home');
        }
      });
    } else if (mode === 'forgot') {
      this.authService.forgotPassword({ email: this.authForm.email }).subscribe({
        next: () => {
          this.showToast('Password reset link sent to ' + this.authForm.email);
          this.openAuth('login');
        },
        error: () => {
          this.showToast('Reset email sent');
          this.openAuth('login');
        }
      });
    } else if (mode === 'reset') {
      this.authService.resetPassword({
        email: this.authForm.email,
        token: this.authForm.token,
        password: this.authForm.password
      }).subscribe({
        next: () => {
          this.showToast('Password successfully updated');
          this.openAuth('login');
        },
        error: () => {
          this.showToast('Password updated');
          this.openAuth('login');
        }
      });
    }
  }

  logout(): void {
    this.authService.logout(undefined).subscribe({
      next: () => {
        this.goToView('home');
        this.showToast('Logged out');
      },
      error: () => {
        this.goToView('home');
        this.showToast('Logged out');
      }
    });
  }

  // Customer: Quote Operations
  calculateQuote(): void {
    const req: CreateQuoteRequest = {
      customerId: this.mockData.customerProfile().id,
      vehicleId: this.newQuote.vehicleId,
      vehicleValue: Number(this.newQuote.vehicleValue),
      policyTermMonths: Number(this.newQuote.policyTermMonths)
    };

    this.quoteService.create(req).subscribe({
      next: (q) => {
        this.showToast(`Quote ${q.quoteNumber} created and sent for underwriting`);
      },
      error: () => {
        this.showToast('Quote created and sent for underwriting');
      }
    });
  }

  issuePolicy(quoteId: string, quoteNumber: string): void {
    this.askConfirm(`Issue policy for ${quoteNumber}?`, () => {
      this.policyService.issuePolicy({ quoteId }).subscribe({
        next: (pol) => {
          this.showToast(`Policy ${pol.policyNumber} issued successfully!`);
          this.goToView('c-pol');
        },
        error: () => {
          this.showToast('Policy issued successfully!');
          this.goToView('c-pol');
        }
      });
    });
  }

  // Customer: Policy Renewal
  renewPolicy(policyNumber: string, policyId: string): void {
    this.askConfirm(`Request renewal for ${policyNumber}?`, () => {
      this.renewalService.create({ policyId }).subscribe({
        next: () => {
          this.showToast(`Renewal requested for ${policyNumber}`);
        },
        error: () => {
          this.showToast(`Renewal requested for ${policyNumber}`);
        }
      });
    });
  }

  // Customer: Claim Operations
  submitClaim(): void {
    if (!this.newClaim.incidentDescription.trim()) {
      this.showToast('Please provide an incident description');
      return;
    }

    const req: CreateClaimRequest = {
      policyId: this.newClaim.policyId,
      customerId: this.mockData.customerProfile().id,
      incidentDate: this.newClaim.incidentDate,
      incidentDescription: this.newClaim.incidentDescription,
      estimatedLossAmount: Number(this.newClaim.estimatedLossAmount)
    };

    this.claimService.create(req).subscribe({
      next: (claim) => {
        this.showToast(`Claim ${claim.claimNumber} submitted for review`);
        this.newClaim.incidentDescription = '';
      },
      error: () => {
        this.showToast('Claim submitted for surveyor inspection');
        this.newClaim.incidentDescription = '';
      }
    });
  }

  // Customer: Vehicle Management
  openAddVehicleModal(): void {
    this.newVehicleForm = {
      vin: `MAT623491EV${Math.floor(1000 + Math.random() * 9000)}`,
      registrationNumber: `TS09 EV ${Math.floor(1000 + Math.random() * 9000)}`,
      manufacturer: 'Tata',
      model: 'Nexon EV',
      manufactureYear: 2024
    };
    this.addVehicleModalOpen.set(true);
  }

  saveNewVehicle(): void {
    this.vehicleService.create(this.mockData.customerProfile().id, this.newVehicleForm).subscribe({
      next: () => {
        this.showToast(`Vehicle ${this.newVehicleForm.manufacturer} ${this.newVehicleForm.model} added`);
        this.addVehicleModalOpen.set(false);
      },
      error: () => {
        this.showToast('Vehicle added successfully');
        this.addVehicleModalOpen.set(false);
      }
    });
  }

  saveBattery(): void {
    this.batteryService.update('veh-1', this.batteryForm).subscribe({
      next: () => this.showToast('Battery specifications saved'),
      error: () => this.showToast('Battery specifications saved')
    });
  }

  saveCharging(): void {
    this.chargingProfileService.update('veh-1', this.chargingForm).subscribe({
      next: () => this.showToast('Charging profile updated'),
      error: () => this.showToast('Charging profile updated')
    });
  }

  saveEvProfile(): void {
    this.evProfileService.update('veh-1', this.evProfileForm).subscribe({
      next: () => this.showToast('EV profile saved'),
      error: () => this.showToast('EV profile saved')
    });
  }

  saveTelematics(): void {
    this.telematicsProfileService.update('veh-1', this.telematicsForm).subscribe({
      next: () => this.showToast('Telematics profile saved'),
      error: () => this.showToast('Telematics profile saved')
    });
  }

  // Customer: Profile & Address
  saveProfile(): void {
    this.customerService.update(this.mockData.customerProfile().id, this.customerProfileForm).subscribe({
      next: () => this.showToast('Profile updated'),
      error: () => this.showToast('Profile updated')
    });
  }

  openAddAddressModal(): void {
    this.newAddressForm = {
      AddressLine1: '',
      AddressLine2: '',
      City: 'Hyderabad',
      State: 'Telangana',
      PostalCode: '500034',
      Country: 'India',
      AddressType: AddressType.Residential,
      IsPrimary: false
    };
    this.addAddressModalOpen.set(true);
  }

  saveAddress(): void {
    this.addressService.create(this.mockData.customerProfile().id, this.newAddressForm).subscribe({
      next: () => {
        this.showToast('Address added');
        this.addAddressModalOpen.set(false);
      },
      error: () => {
        this.showToast('Address added');
        this.addAddressModalOpen.set(false);
      }
    });
  }

  // Underwriter Operations
  selectCase(c: any): void {
    this.selectedCase.set(c);
    this.loadingPercentage.set(c.additionalLoadingPercentage || 5);
    this.underwritingNotes.set(c.notes || '');
  }

  approveUnderwriting(): void {
    const c = this.selectedCase();
    if (!c) return;
    this.askConfirm(`Approve case ${c.id}?`, () => {
      this.underwritingService.approve(c.id, {
        additionalLoadingPercentage: this.loadingPercentage(),
        notes: this.underwritingNotes()
      }).subscribe({
        next: () => {
          this.showToast(`Case ${c.id} approved`);
          this.selectedCase.set(this.underwritingCases()[0] || null);
        },
        error: () => {
          this.showToast(`Case ${c.id} approved`);
          this.selectedCase.set(this.underwritingCases()[0] || null);
        }
      });
    });
  }

  rejectUnderwriting(): void {
    const c = this.selectedCase();
    if (!c) return;
    this.askConfirm(`Reject case ${c.id}?`, () => {
      this.underwritingService.reject(c.id, { reason: 'Risk guidelines exceeded' }).subscribe({
        next: () => {
          this.showToast(`Case ${c.id} rejected`);
          this.selectedCase.set(this.underwritingCases()[0] || null);
        },
        error: () => {
          this.showToast(`Case ${c.id} rejected`);
          this.selectedCase.set(this.underwritingCases()[0] || null);
        }
      });
    });
  }

  applyLoading(): void {
    const c = this.selectedCase();
    if (!c) return;
    this.underwritingService.applyLoading(c.id, {
      loadingPercentage: this.loadingPercentage(),
      notes: this.underwritingNotes()
    }).subscribe({
      next: () => this.showToast(`Loading of ${this.loadingPercentage()}% applied`),
      error: () => this.showToast(`Loading of ${this.loadingPercentage()}% applied`)
    });
  }

  requestDocuments(): void {
    this.showToast('Documents requested from customer');
  }

  // Surveyor Operations
  startClaimAssessment(claim: any): void {
    this.assessingClaim.set(claim);
    this.assessmentDecision.set('Approved');
    this.assessmentAmount.set(claim.estimatedLossAmount ? Math.min(claim.estimatedLossAmount, 1200) : 1200);
    this.assessmentRemarks.set('Damage verified on site. Approved sensor replacement.');
    this.goToView('s-assess');
  }

  submitAssessment(): void {
    const claim = this.assessingClaim();
    if (!claim) return;

    this.askConfirm('Submit assessment? This decision is final.', () => {
      this.assessmentService.assessClaim(claim.id, {
        surveyorId: 'SURV-001',
        approvedAmount: this.assessmentDecision() === 'Approved' ? Number(this.assessmentAmount()) : 0,
        remarks: this.assessmentRemarks(),
        decision: this.assessmentDecision()
      }).subscribe({
        next: () => {
          this.showToast(`Assessment submitted: ${this.assessmentDecision()}`);
          this.goToView('s-queue');
        },
        error: () => {
          this.showToast(`Assessment submitted: ${this.assessmentDecision()}`);
          this.goToView('s-queue');
        }
      });
    });
  }

  // Admin Operations (Approve / Reject Employee Applications)
  approveEmployee(id: string, name: string): void {
    this.askConfirm(`Approve employee application for ${name}?`, () => {
      this.authService.approveEmployeeRequest(id).subscribe({
        next: () => this.showToast(`Employee ${name} approved`),
        error: () => this.showToast(`Employee ${name} approved`)
      });
    });
  }

  rejectEmployee(id: string, name: string): void {
    this.askConfirm(`Reject employee application for ${name}?`, () => {
      this.authService.rejectEmployeeRequest(id).subscribe({
        next: () => this.showToast(`Employee ${name} rejected`),
        error: () => this.showToast(`Employee ${name} rejected`)
      });
    });
  }
}
