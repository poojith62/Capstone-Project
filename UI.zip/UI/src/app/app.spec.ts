import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideHttpClient()]
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should start with home view by default', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app.currentView()).toBe('home');
  });

  it('should navigate to auth login view when requested', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    app.openAuth('login');
    expect(app.currentView()).toBe('auth');
    expect(app.authMode()).toBe('login');
  });
});
