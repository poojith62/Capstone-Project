export interface QuoteResponse {
  id: string;
  quoteNumber: string;
  riskScore: number;
  riskBand: string;
  basePremium: number;
  loadingAmount: number;
  finalPremium: number;
  status: string;
  vehicleModel?: string;
  customerId?: string;
  vehicleId?: string;
}
