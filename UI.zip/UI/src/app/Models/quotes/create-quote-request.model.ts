export interface CreateQuoteRequest {
  customerId: string;
  vehicleId: string;
  vehicleValue: number;
  policyTermMonths: number;
}
