export interface RiskAssessmentResponse {
  riskScore: number;
  riskBand: string;
  loadingPercentage: number;
  assessmentSummary: string;
}
