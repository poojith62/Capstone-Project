export interface CreatePolicyRequest {
  quoteId: string;
}
