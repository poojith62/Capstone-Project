export interface PolicyResponse {
  id: string;
  policyNumber: string;
  premiumAmount: number;
  status: string;
  effectiveDate: string;
  expiryDate: string;
  customerId?: string;
  vehicleId?: string;
  vehicleModel?: string;
}
