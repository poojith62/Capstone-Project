export interface CreateRenewalRequest {
  policyId: string;
}
