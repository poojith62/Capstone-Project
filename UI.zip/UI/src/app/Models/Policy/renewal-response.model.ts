export interface RenewalResponse {
  renewalRequestId: string;
  policyId: string;
  renewalQuoteId: string;
  status: string;
}
