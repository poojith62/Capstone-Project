import { ClaimStatus } from "./claim-status.enum";

export interface ClaimResponse {
  id: string;
  claimNumber: string;
  status: ClaimStatus;
  estimatedLossAmount: number;
  policyId?: string;
  customerId?: string;
  incidentDate?: string;
  incidentDescription?: string;
  approvedAmount?: number;
  remarks?: string;
  surveyorId?: string;
  createdAt?: string;
}
