export class PaymentStatusResponse {
  paymentId!: string;
  quoteId!: string;
  amount!: number;
  transactionReference!: string;
  status!: string;
}

export type PaymentResponse = PaymentStatusResponse;
