export interface CreateAssessmentRequest {
  surveyorId: string;
  approvedAmount: number;
  remarks: string;
  decision: 'Approved' | 'Rejected';
}
