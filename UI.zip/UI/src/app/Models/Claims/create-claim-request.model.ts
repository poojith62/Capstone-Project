export interface CreateClaimRequest {
  policyId: string;
  customerId: string;
  incidentDate: string;
  incidentDescription: string;
  estimatedLossAmount: number;
}
