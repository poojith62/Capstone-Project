export enum ClaimStatus {
  Submitted = 'Submitted',
  UnderReview = 'UnderReview',
  Approved = 'Approved',
  Rejected = 'Rejected',
  Settled = 'Settled',
  Closed = 'Closed'
}
