export interface EmployeeRequestResponse {
  id: string;
  fullName: string;
  email: string;
  role: string;
  employeeTypeId: number;
  status: string;
  requestedAt: string;
}
