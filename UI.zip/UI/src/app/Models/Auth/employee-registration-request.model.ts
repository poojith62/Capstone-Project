export interface EmployeeRegistrationRequest {
  fullName: string;
  email: string;
  phoneNumber: string;
  password: string;
  employeeTypeId: number;
}
