import { AddressType } from "./address-type.enum";

export interface CreateAddressRequest {
  AddressLine1: string;
  AddressLine2: string;
  City: string;
  State: string;
  PostalCode: string;
  Country: string;
  AddressType: AddressType;
  IsPrimary: boolean;
}
