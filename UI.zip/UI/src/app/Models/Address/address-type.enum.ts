export enum AddressType {
  Residential = 1,
  Correspondence = 2
}
