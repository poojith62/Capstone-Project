export interface AddressResponse {
  Id: string;
  CustomerId: string;
  AddressLine1: string;
  AddressLine2: string;
  City: string;
  State: string;
  PostalCode: string;
  Country: string;
  AddressType: string;
  IsPrimary: boolean;
}
