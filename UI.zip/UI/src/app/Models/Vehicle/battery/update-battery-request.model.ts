import { BatteryStatus } from "./battery-status.enum";

export interface UpdateBatteryRequest {
  StateOfHealth: number;
  RatedCapacityKwh: number;
  CurrentCapacityKwh: number;
  CycleCount: number;
  BatteryAgeMonths: number;
  Status: BatteryStatus;
}
