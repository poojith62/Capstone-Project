export enum BatteryStatus {
  Excellent = 1,
  Good = 2,
  Fair = 3,
  Poor = 4
}
