export interface EVProfileResponse {
  VehicleId: string;
  BatteryCapacityKwh: number;
  RangeKm: number;
  MotorPowerKw: number;
  MaxChargingSpeedKw: number;
  BatteryChemistry: string;
  DriveType: string;
}
