export interface BatteryResponse {
  VehicleId: string;
  StateOfHealth: number;
  RatedCapacityKwh: number;
  CurrentCapacityKwh: number;
  CycleCount: number;
  BatteryAgeMonths: number;
  Status: string;
}
