export interface UpdateEVProfileRequest {
  BatteryCapacityKwh: number;
  RangeKm: number;
  MotorPowerKw: number;
  MaxChargingSpeedKw: number;
  BatteryChemistry: string;
  DriveType: string;
}
