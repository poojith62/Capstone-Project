export interface UpdateChargingProfileRequest {
  homeChargingPercentage: number;
  publicChargingPercentage: number;
  fastChargingPercentage: number;
}
