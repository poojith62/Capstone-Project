export interface ChargingProfileResponse {
  vehicleId: string;
  homeChargingPercentage: number;
  publicChargingPercentage: number;
  fastChargingPercentage: number;
}
