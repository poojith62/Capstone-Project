export interface TelematicsProfileResponse {
  vehicleId: string;
  totalDistanceKm: number;
  averageDailyDistanceKm: number;
  efficiencyKmPerKwh: number;
}
