export interface UpdateTelematicsProfileRequest {
  totalDistanceKm: number;
  averageDailyDistanceKm: number;
  efficiencyKmPerKwh: number;
}
