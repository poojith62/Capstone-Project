export enum VehicleStatus {
  Active = 1,
  Inactive = 2,
  Sold = 3
}
