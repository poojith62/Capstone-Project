export interface CreateVehicleRequest {
  vin: string;
  registrationNumber: string;
  manufacturer: string;
  model: string;
  manufactureYear: number;
}
