import { VehicleStatus } from "./vehicle-status.enum";

export interface UpdateVehicleRequest {
  manufacturer: string;
  model: string;
  manufactureYear: number;
  status: VehicleStatus;
}
