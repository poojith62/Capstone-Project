export interface VehicleResponse {
  id: string;
  customerId: string;
  vin: string;
  registrationNumber: string;
  manufacturer: string;
  model: string;
  manufactureYear: number;
  status: string;
}
