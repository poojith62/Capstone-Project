export class CreateBatteryHealthRecordRequest {
  stateOfHealth!: number;
  currentCapacityKwh!: number;
}
