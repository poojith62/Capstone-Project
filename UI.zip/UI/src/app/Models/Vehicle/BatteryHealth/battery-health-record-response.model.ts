export interface BatteryHealthRecordResponse {
  Id: string;
  VehicleId: string;
  StateOfHealth: number;
  CurrentCapacityKwh: number;
  RecordedAt: string;
}
