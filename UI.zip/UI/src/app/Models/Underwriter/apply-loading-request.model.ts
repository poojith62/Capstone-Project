export interface ApplyLoadingRequest {
  loadingPercentage: number;
  notes: string;
}
