export interface UnderwritingCaseResponse {
  id: string;
  quoteId: string;
  decision: string;
  additionalLoadingPercentage: number;
  notes: string;
  customerName?: string;
  vehicleModel?: string;
  riskScore?: number;
  premium?: number;
  batteryHealth?: string;
}
