export interface ApproveQuoteRequest {
  additionalLoadingPercentage: number;
  notes: string;
}
