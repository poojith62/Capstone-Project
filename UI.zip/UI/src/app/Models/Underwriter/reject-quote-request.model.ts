export interface RejectQuoteRequest {
  reason: string;
}
