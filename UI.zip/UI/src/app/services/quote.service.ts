import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateQuoteRequest } from '../Models/quotes/create-quote-request.model';
import { QuoteResponse } from '../Models/quotes/quote-response.model';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private readonly url = '/api/quotes';

  constructor(private http: HttpClient) {}

  create(request: CreateQuoteRequest): Observable<QuoteResponse> {
    return this.http.post<QuoteResponse>(
      this.url,
      request
    );
  }

  getCustomerQuotes(customerId: string): Observable<QuoteResponse[]> {
    return this.http.get<QuoteResponse[]>(
      `${this.url}/customer/${customerId}`
    );
  }

  getQuote(quoteId: string): Observable<QuoteResponse> {
    return this.http.get<QuoteResponse>(
      `${this.url}/${quoteId}`
    );
  }
}
