import { HttpInterceptorFn, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { of, throwError } from 'rxjs';
import { catchError, delay } from 'rxjs/operators';
import { MockDataService } from './mock-data.service';

export const apiFallbackInterceptor: HttpInterceptorFn = (req, next) => {
  const mock = inject(MockDataService);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      // If server is not running (status 0) or returns 404/500 during local UI testing, provide smart mock responses
      const url = req.url;
      const method = req.method;

      // Auth login
      if (url.includes('/api/auth/login')) {
        return of(new HttpResponse({ status: 200, body: { token: 'mock-jwt-token', user: { email: (req.body as any)?.email, role: 'Customer' } } }));
      }
      // Auth register
      if (url.includes('/api/auth/register')) {
        return of(new HttpResponse({ status: 201, body: { message: 'Registered successfully' } }));
      }
      // Auth apply
      if (url.includes('/api/auth/apply') || url.includes('/employee/apply')) {
        if (req.body) {
          mock.addEmployeeRequest(req.body);
        }
        return of(new HttpResponse({ status: 201, body: { message: 'Application submitted successfully' } }));
      }
      // Admin pending requests
      if (url.includes('/api/admin/pending-requests')) {
        return of(new HttpResponse({ status: 200, body: mock.employeeRequests() }));
      }
      // Admin approve
      if (url.includes('/api/admin/approve/')) {
        const parts = url.split('/');
        const id = parts[parts.length - 1];
        mock.approveEmployee(id);
        return of(new HttpResponse({ status: 200, body: { message: 'Approved' } }));
      }
      // Admin reject
      if (url.includes('/api/admin/reject/')) {
        const parts = url.split('/');
        const id = parts[parts.length - 1];
        mock.rejectEmployee(id);
        return of(new HttpResponse({ status: 200, body: { message: 'Rejected' } }));
      }
      // Underwriting pending
      if (url.includes('/api/underwriting/pending')) {
        return of(new HttpResponse({ status: 200, body: mock.underwritingCases() }));
      }
      // Underwriting approve
      if (url.includes('/api/underwriting/') && url.endsWith('/approve')) {
        const match = url.match(/\/api\/underwriting\/(.+)\/approve/);
        if (match && match[1]) mock.approveUnderwritingCase(match[1]);
        return of(new HttpResponse({ status: 200, body: null }));
      }
      // Underwriting reject
      if (url.includes('/api/underwriting/') && url.endsWith('/reject')) {
        const match = url.match(/\/api\/underwriting\/(.+)\/reject/);
        if (match && match[1]) mock.rejectUnderwritingCase(match[1]);
        return of(new HttpResponse({ status: 200, body: null }));
      }
      // Underwriting apply loading
      if (url.includes('/api/underwriting/') && url.endsWith('/apply-loading')) {
        const match = url.match(/\/api\/underwriting\/(.+)\/apply-loading/);
        const body = req.body as any;
        if (match && match[1]) mock.applyCaseLoading(match[1], body?.loadingPercentage || 5, body?.notes);
        return of(new HttpResponse({ status: 200, body: null }));
      }
      // Claims pending
      if (url.includes('/api/claims/pending')) {
        return of(new HttpResponse({ status: 200, body: mock.claims() }));
      }
      // Claims assessment
      if (url.includes('/api/claims/') && url.endsWith('/assessment')) {
        const match = url.match(/\/api\/claims\/(.+)\/assessment/);
        const res = mock.assessClaim(match ? match[1] : 'CL-501', req.body);
        return of(new HttpResponse({ status: 200, body: res }));
      }
      // Claims create
      if (url.includes('/api/claims') && method === 'POST') {
        const res = mock.addClaim(req.body);
        return of(new HttpResponse({ status: 201, body: res }));
      }
      // Claims get customer
      if (url.includes('/api/claims/customer/')) {
        return of(new HttpResponse({ status: 200, body: mock.claims() }));
      }
      // Customer profile
      if (url.includes('/api/customers/me')) {
        return of(new HttpResponse({ status: 200, body: mock.customerProfile() }));
      }
      // Customer addresses
      if (url.includes('/addresses')) {
        if (method === 'POST') {
          const res = mock.addAddress(req.body);
          return of(new HttpResponse({ status: 201, body: res }));
        }
        return of(new HttpResponse({ status: 200, body: mock.addresses() }));
      }
      // Customer vehicles
      if (url.includes('/vehicles')) {
        if (method === 'POST') {
          const res = mock.addVehicle(req.body);
          return of(new HttpResponse({ status: 201, body: res }));
        }
        if (url.includes('/battery/health-records')) {
          return of(new HttpResponse({ status: 200, body: [{ Id: 'rec-1', VehicleId: 'veh-1', StateOfHealth: 84, CurrentCapacityKwh: 34.02, RecordedAt: '01 Oct 2026' }] }));
        }
        if (url.includes('/battery')) {
          return of(new HttpResponse({ status: 200, body: mock.vehicleBattery() }));
        }
        if (url.includes('/charging-profile')) {
          return of(new HttpResponse({ status: 200, body: mock.vehicleCharging() }));
        }
        if (url.includes('/ev-profile')) {
          return of(new HttpResponse({ status: 200, body: mock.vehicleEvProfile() }));
        }
        if (url.includes('/telematics-profile')) {
          return of(new HttpResponse({ status: 200, body: mock.vehicleTelematics() }));
        }
        return of(new HttpResponse({ status: 200, body: mock.vehicles() }));
      }
      // Quotes
      if (url.includes('/api/quotes')) {
        if (method === 'POST') {
          const res = mock.addQuote(req.body);
          return of(new HttpResponse({ status: 201, body: res }));
        }
        return of(new HttpResponse({ status: 200, body: mock.quotes() }));
      }
      // Policies
      if (url.includes('/api/policies')) {
        if (method === 'POST') {
          const res = mock.issuePolicy((req.body as any)?.quoteId);
          return of(new HttpResponse({ status: 201, body: res }));
        }
        return of(new HttpResponse({ status: 200, body: mock.policies() }));
      }
      // Renewals
      if (url.includes('/api/renewals')) {
        return of(new HttpResponse({ status: 201, body: { renewalRequestId: 'REN-1', policyId: (req.body as any)?.policyId, renewalQuoteId: 'Q-2041', status: 'Pending' } }));
      }

      return throwError(() => error);
    })
  );
};
