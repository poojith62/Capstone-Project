import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EVProfileResponse } from '../Models/Vehicle/battery/Ev-profile-response.model';
import { UpdateEVProfileRequest } from '../Models/Vehicle/battery/update-ev-profile-request.model';
import { environment } from '../../environment/environment';

@Injectable({
  providedIn: 'root'
})
export class EvProfileService {
  private readonly baseUrl = environment?.apiUrl ? `${environment.apiUrl}/api/vehicles` : 'https://localhost:5001/api/vehicles';

  constructor(private http: HttpClient) {}

  get(vehicleId: string): Observable<EVProfileResponse> {
    return this.http.get<EVProfileResponse>(
      `${this.baseUrl}/${vehicleId}/ev-profile`
    );
  }

  update(
    vehicleId: string,
    request: UpdateEVProfileRequest
  ): Observable<EVProfileResponse> {
    return this.http.put<EVProfileResponse>(
      `${this.baseUrl}/${vehicleId}/ev-profile`,
      request
    );
  }
}
