import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ChargingProfileResponse } from '../Models/Vehicle/ChargingProfile/charging-profile-response.model';
import { UpdateChargingProfileRequest } from '../Models/Vehicle/ChargingProfile/update-charging-profile-request.model';

@Injectable({
  providedIn: 'root'
})
export class ChargingProfileService {
  private readonly url = '/api/vehicles';

  constructor(private http: HttpClient) {}

  get(vehicleId: string): Observable<ChargingProfileResponse> {
    return this.http.get<ChargingProfileResponse>(
      `${this.url}/${vehicleId}/charging-profile`
    );
  }

  update(
    vehicleId: string,
    request: UpdateChargingProfileRequest
  ): Observable<ChargingProfileResponse> {
    return this.http.put<ChargingProfileResponse>(
      `${this.url}/${vehicleId}/charging-profile`,
      request
    );
  }
}
