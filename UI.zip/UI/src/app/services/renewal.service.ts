import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateRenewalRequest } from '../Models/Policy/create-renewal-request.model';
import { RenewalResponse } from '../Models/Policy/renewal-response.model';

@Injectable({
  providedIn: 'root'
})
export class RenewalService {
  private readonly url = '/api/renewals';

  constructor(private http: HttpClient) {}

  create(request: CreateRenewalRequest): Observable<RenewalResponse> {
    return this.http.post<RenewalResponse>(
      this.url,
      request
    );
  }
}
