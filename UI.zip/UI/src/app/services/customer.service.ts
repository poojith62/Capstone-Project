import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateCustomerRequest } from '../Models/Customer/create-customer-request.model';
import { CustomerResponse } from '../Models/Customer/customer-response.model';
import { UpdateCustomerRequest } from '../Models/Customer/update-customer-request.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private readonly url = '/api/customers';

  constructor(private http: HttpClient) {}

  create(request: CreateCustomerRequest): Observable<CustomerResponse> {
    return this.http.post<CustomerResponse>(
      this.url,
      request
    );
  }

  getMyProfile(): Observable<CustomerResponse> {
    return this.http.get<CustomerResponse>(
      `${this.url}/me`
    );
  }

  getById(customerId: string): Observable<CustomerResponse> {
    return this.http.get<CustomerResponse>(
      `${this.url}/${customerId}`
    );
  }

  update(
    customerId: string,
    request: UpdateCustomerRequest
  ): Observable<CustomerResponse> {
    return this.http.put<CustomerResponse>(
      `${this.url}/${customerId}`,
      request
    );
  }
}
