import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateAddressRequest } from '../Models/Address/create-address-request.model';
import { AddressResponse } from '../Models/Address/address-response.model';

@Injectable({
  providedIn: 'root'
})
export class AddressService {
  private readonly url = '/api/customers';

  constructor(private http: HttpClient) {}

  create(customerId: string, request: CreateAddressRequest): Observable<AddressResponse> {
    return this.http.post<AddressResponse>(
      `${this.url}/${customerId}/addresses`,
      request
    );
  }

  get(customerId: string): Observable<AddressResponse[]> {
    return this.http.get<AddressResponse[]>(
      `${this.url}/${customerId}/addresses`
    );
  }

  update(customerId: string, addressId: string, request: CreateAddressRequest): Observable<AddressResponse> {
    return this.http.put<AddressResponse>(
      `${this.url}/${customerId}/addresses/${addressId}`,
      request
    );
  }

  delete(customerId: string, addressId: string): Observable<void> {
    return this.http.delete<void>(
      `${this.url}/${customerId}/addresses/${addressId}`
    );
  }
}
