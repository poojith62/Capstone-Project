import { Injectable, signal } from '@angular/core';
import { ClaimStatus } from '../Models/Claims/claim-status.enum';
import { VehicleStatus } from '../Models/Vehicle/vehicles/vehicle-status.enum';
import { AddressType } from '../Models/Address/address-type.enum';

@Injectable({
  providedIn: 'root'
})
export class MockDataService {
  readonly quotes = signal([
    { id: 'Q-2041', quoteNumber: 'Q-2041', customerId: 'cust-1', vehicleId: 'veh-1', vehicleModel: 'Tata Nexon EV', vehicleValue: 1450000, basePremium: 17500, loadingAmount: 950, finalPremium: 18450, riskScore: 72, riskBand: 'Medium', status: 'Approved' },
    { id: 'Q-2042', quoteNumber: 'Q-2042', customerId: 'cust-1', vehicleId: 'veh-2', vehicleModel: 'MG ZS EV', vehicleValue: 2200000, basePremium: 16200, loadingAmount: 700, finalPremium: 16900, riskScore: 58, riskBand: 'Low', status: 'Pending' },
    { id: 'Q-2043', quoteNumber: 'Q-2043', customerId: 'cust-1', vehicleId: 'veh-1', vehicleValue: 1800000, basePremium: 19500, loadingAmount: 1800, finalPremium: 21300, riskScore: 81, riskBand: 'High', status: 'Documents requested' }
  ]);

  readonly policies = signal([
    { id: 'EV-90112', policyNumber: 'EV-90112', quoteId: 'Q-2041', customerId: 'cust-1', vehicleId: 'veh-1', vehicleModel: 'Tata Nexon EV', premiumAmount: 18450, status: 'Active', effectiveDate: '01 Jan 2026', expiryDate: '31 Dec 2026' }
  ]);

  readonly claims = signal([
    { id: 'CL-501', claimNumber: 'CL-501', policyId: 'EV-90112', customerId: 'cust-1', customerName: 'Poojith', vehicleModel: 'Tata Nexon EV', incidentDate: '28 Sep 2026', incidentDescription: 'Minor collision at roundabout causing front sensor damage', estimatedLossAmount: 1500, status: ClaimStatus.Approved, approvedAmount: 1200, remarks: 'Damage verified on site. Approved sensor replacement.', surveyorId: 'surv-1', createdAt: '28 Sep 2026' },
    { id: 'CL-502', claimNumber: 'CL-502', policyId: 'EV-90112', customerId: 'cust-1', customerName: 'Poojith', vehicleModel: 'Tata Nexon EV', incidentDate: '01 Oct 2026', incidentDescription: 'Rear bumper scratch and dent in parking lot', estimatedLossAmount: 1800, status: ClaimStatus.Submitted, approvedAmount: 0, remarks: '', surveyorId: '', createdAt: '01 Oct 2026' }
  ]);

  readonly vehicles = signal([
    { id: 'veh-1', customerId: 'cust-1', vin: 'MAT623491EV00192', registrationNumber: 'TS09 EV 4821', manufacturer: 'Tata', model: 'Nexon EV', manufactureYear: 2023, status: 'Active' },
    { id: 'veh-2', customerId: 'cust-1', vin: 'MGZ882910EV99281', registrationNumber: 'TS09 EV 9912', manufacturer: 'MG', model: 'ZS EV', manufactureYear: 2024, status: 'Active' }
  ]);

  readonly vehicleBattery = signal({
    VehicleId: 'veh-1',
    StateOfHealth: 84,
    RatedCapacityKwh: 40.5,
    CurrentCapacityKwh: 34.02,
    CycleCount: 420,
    BatteryAgeMonths: 18,
    Status: 'Good'
  });

  readonly vehicleCharging = signal({
    vehicleId: 'veh-1',
    homeChargingPercentage: 75,
    publicChargingPercentage: 15,
    fastChargingPercentage: 10
  });

  readonly vehicleEvProfile = signal({
    VehicleId: 'veh-1',
    BatteryCapacityKwh: 40.5,
    RangeKm: 312,
    MotorPowerKw: 105,
    MaxChargingSpeedKw: 50,
    BatteryChemistry: 'Li-ion NMC',
    DriveType: 'FWD'
  });

  readonly vehicleTelematics = signal({
    vehicleId: 'veh-1',
    totalDistanceKm: 24800,
    averageDailyDistanceKm: 38.3,
    efficiencyKmPerKwh: 7.7
  });

  readonly customerProfile = signal({
    id: 'cust-1',
    customerNumber: 'CUST-10023',
    userId: 'usr-1',
    firstName: 'Poojith',
    lastName: 'Kumar',
    email: 'poojith@evsure.com',
    phoneNumber: '+91 90000 00000',
    status: 'Active',
    createdAt: '2025-01-15'
  });

  readonly addresses = signal([
    { Id: 'addr-1', CustomerId: 'cust-1', AddressLine1: '12-4, Road 5', AddressLine2: 'Banjara Hills', City: 'Hyderabad', State: 'Telangana', PostalCode: '500034', Country: 'India', AddressType: 'Residential', IsPrimary: true }
  ]);

  readonly documents = signal([
    { id: 'doc-1', name: 'driving-licence.pdf', type: 'Licence', uploaded: '12 Sep 2026' },
    { id: 'doc-2', name: 'rc-book.pdf', type: 'RC', uploaded: '12 Sep 2026' }
  ]);

  readonly underwritingCases = signal([
    { id: 'C-1041', quoteId: 'Q-2041', decision: 'UnderReview', additionalLoadingPercentage: 5, notes: 'EV battery health 84% inspected', customerName: 'Poojith', vehicleModel: 'Tata Nexon EV', riskScore: 72, premium: 18450, batteryHealth: '84%' },
    { id: 'C-1042', quoteId: 'Q-2042', decision: 'UnderReview', additionalLoadingPercentage: 0, notes: 'Low risk score', customerName: 'Anita R.', vehicleModel: 'MG ZS EV', riskScore: 58, premium: 16900, batteryHealth: '91%' }
  ]);

  readonly employeeRequests = signal([
    { id: 'emp-1', fullName: 'Anita Rao', email: 'anita@evsure.com', role: 'Underwriter', employeeTypeId: 2, status: 'Pending', requestedAt: '28 Sep 2026' },
    { id: 'emp-2', fullName: 'Ravi Kumar', email: 'ravi@evsure.com', role: 'Surveyor', employeeTypeId: 3, status: 'Pending', requestedAt: '30 Sep 2026' }
  ]);

  // Operations for full local reactivity
  addQuote(quote: any): any {
    const newQ = {
      ...quote,
      id: `Q-${Math.floor(2000 + Math.random() * 8000)}`,
      quoteNumber: `Q-${Math.floor(2000 + Math.random() * 8000)}`,
      riskScore: Math.floor(50 + Math.random() * 35),
      riskBand: 'Standard',
      basePremium: 17500,
      loadingAmount: 850,
      finalPremium: 18350,
      status: 'Pending'
    };
    this.quotes.update(list => [newQ, ...list]);
    this.underwritingCases.update(cases => [
      {
        id: `C-${Math.floor(1000 + Math.random() * 9000)}`,
        quoteId: newQ.id,
        decision: 'UnderReview',
        additionalLoadingPercentage: 0,
        notes: 'Newly calculated quote',
        customerName: this.customerProfile().firstName,
        vehicleModel: quote.vehicleModel || 'Electric Vehicle',
        riskScore: newQ.riskScore,
        premium: newQ.finalPremium,
        batteryHealth: '85%'
      },
      ...cases
    ]);
    return newQ;
  }

  issuePolicy(quoteId: string): any {
    const q = this.quotes().find(x => x.id === quoteId);
    const newPol = {
      id: `EV-${Math.floor(90000 + Math.random() * 9999)}`,
      policyNumber: `EV-${Math.floor(90000 + Math.random() * 9999)}`,
      quoteId: quoteId,
      customerId: this.customerProfile().id,
      vehicleId: q?.vehicleId || 'veh-1',
      vehicleModel: q?.vehicleModel || 'Tata Nexon EV',
      premiumAmount: q?.finalPremium || 18450,
      status: 'Active',
      effectiveDate: '01 Nov 2026',
      expiryDate: '31 Oct 2027'
    };
    this.policies.update(list => [newPol, ...list]);
    this.quotes.update(list => list.map(item => item.id === quoteId ? { ...item, status: 'Policy Issued' } : item));
    return newPol;
  }

  addClaim(claim: any): any {
    const newClaim = {
      id: `CL-${Math.floor(500 + Math.random() * 499)}`,
      claimNumber: `CL-${Math.floor(500 + Math.random() * 499)}`,
      policyId: claim.policyId,
      customerId: this.customerProfile().id,
      customerName: this.customerProfile().firstName,
      vehicleModel: 'Tata Nexon EV',
      incidentDate: claim.incidentDate || 'Today',
      incidentDescription: claim.incidentDescription,
      estimatedLossAmount: claim.estimatedLossAmount || 2000,
      status: ClaimStatus.Submitted,
      approvedAmount: 0,
      remarks: '',
      surveyorId: '',
      createdAt: 'Today'
    };
    this.claims.update(list => [newClaim, ...list]);
    return newClaim;
  }

  assessClaim(claimId: string, assessment: any): any {
    this.claims.update(list => list.map(c => {
      if (c.id === claimId) {
        return {
          ...c,
          status: assessment.decision === 'Approved' ? ClaimStatus.Approved : ClaimStatus.Rejected,
          approvedAmount: assessment.decision === 'Approved' ? assessment.approvedAmount : 0,
          remarks: assessment.remarks,
          surveyorId: assessment.surveyorId || 'SURV-001'
        };
      }
      return c;
    }));
    return { paymentId: `PAY-${Date.now()}`, quoteId: claimId, amount: assessment.approvedAmount, transactionReference: 'TXN-EV-9921', status: 'Success' };
  }

  approveUnderwritingCase(caseId: string, notes?: string): void {
    this.underwritingCases.update(list => list.filter(c => c.id !== caseId));
  }

  rejectUnderwritingCase(caseId: string, reason?: string): void {
    this.underwritingCases.update(list => list.filter(c => c.id !== caseId));
  }

  applyCaseLoading(caseId: string, loading: number, notes?: string): void {
    this.underwritingCases.update(list => list.map(c => c.id === caseId ? { ...c, additionalLoadingPercentage: loading, notes: notes || c.notes } : c));
  }

  approveEmployee(requestId: string): void {
    this.employeeRequests.update(list => list.filter(e => e.id !== requestId));
  }

  rejectEmployee(requestId: string): void {
    this.employeeRequests.update(list => list.filter(e => e.id !== requestId));
  }

  addEmployeeRequest(req: any): void {
    this.employeeRequests.update(list => [
      ...list,
      {
        id: `emp-${Date.now()}`,
        fullName: req.fullName,
        email: req.email,
        role: req.employeeTypeId === 2 ? 'Underwriter' : 'Surveyor',
        employeeTypeId: req.employeeTypeId,
        status: 'Pending',
        requestedAt: 'Today'
      }
    ]);
  }

  addVehicle(v: any): any {
    const newV = {
      id: `veh-${Date.now()}`,
      customerId: this.customerProfile().id,
      vin: v.vin || 'MAT623491EV' + Math.floor(1000 + Math.random() * 9000),
      registrationNumber: v.registrationNumber,
      manufacturer: v.manufacturer,
      model: v.model,
      manufactureYear: v.manufactureYear || 2024,
      status: 'Active'
    };
    this.vehicles.update(list => [...list, newV]);
    return newV;
  }

  addAddress(a: any): any {
    const newA = {
      Id: `addr-${Date.now()}`,
      CustomerId: this.customerProfile().id,
      AddressLine1: a.AddressLine1,
      AddressLine2: a.AddressLine2,
      City: a.City,
      State: a.State,
      PostalCode: a.PostalCode,
      Country: a.Country,
      AddressType: a.AddressType === 1 ? 'Residential' : 'Correspondence',
      IsPrimary: a.IsPrimary
    };
    this.addresses.update(list => [...list, newA]);
    return newA;
  }
}
