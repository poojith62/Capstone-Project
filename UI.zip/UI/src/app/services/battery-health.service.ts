import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BatteryHealthRecordResponse } from '../Models/Vehicle/BatteryHealth/battery-health-record-response.model';

@Injectable({
  providedIn: 'root'
})
export class BatteryHealthService {
  private readonly url = '/api/vehicles';

  constructor(private http: HttpClient) {}

  getHistory(vehicleId: string): Observable<BatteryHealthRecordResponse[]> {
    return this.http.get<BatteryHealthRecordResponse[]>(
      `${this.url}/${vehicleId}/battery/health-records`
    );
  }
}
