import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';
import { CreateClaimRequest } from '../Models/Claims/create-claim-request.model';
import { ClaimResponse } from '../Models/Claims/claim-response.model';

@Injectable({
  providedIn: 'root'
})
export class ClaimService {
  private url = environment.apiUrl + '/api/claims';

  constructor(private http: HttpClient) {}

  create(body: CreateClaimRequest): Observable<ClaimResponse> {
    return this.http.post<ClaimResponse>(
      this.url,
      body
    );
  }

  getPendingClaims(): Observable<ClaimResponse[]> {
    return this.http.get<ClaimResponse[]>(
      `${this.url}/pending`
    );
  }

  get(claimId: string): Observable<ClaimResponse> {
    return this.http.get<ClaimResponse>(
      `${this.url}/${claimId}`
    );
  }

  getCustomerClaims(customerId: string): Observable<ClaimResponse[]> {
    return this.http.get<ClaimResponse[]>(
      `${this.url}/customer/${customerId}`
    );
  }
}
