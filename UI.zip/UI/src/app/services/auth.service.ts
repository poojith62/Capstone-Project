import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';
import { RegisterRequest } from '../Models/Auth/register-request.model';
import { LoginRequest } from '../Models/Auth/login-request.model';
import { RefreshTokenRequest } from '../Models/Auth/refresh-token-request.model';
import { LogoutRequest } from '../Models/Auth/logout-request.model';
import { ChangePasswordRequest } from '../Models/Auth/change-password-request.model';
import { ForgotPasswordRequest } from '../Models/Auth/forgot-password-request.model';
import { ResetPasswordRequest } from '../Models/Auth/reset-password-request.model';
import { EmployeeRegistrationRequest } from '../Models/Auth/employee-registration-request.model';

export type UserRole = 'Customer' | 'Underwriter' | 'Surveyor' | 'Admin';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private url = environment.apiUrl + '/api/auth';
  private adminUrl = environment.apiUrl + '/api/admin';

  // Role and auth state management
  readonly currentRole = signal<UserRole>('Customer');
  readonly currentUser = signal<{ email: string; name: string; role: UserRole } | null>(null);

  constructor(private http: HttpClient) {}

  register(body: RegisterRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/register`,
      body
    );
  }

  login(body: LoginRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/login`,
      body
    );
  }

  refreshToken(body: RefreshTokenRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/refresh-token`,
      body
    );
  }

  logout(body: LogoutRequest | undefined): Observable<any> {
    this.currentUser.set(null);
    return this.http.post(
      `${this.url}/logout`,
      body
    );
  }

  changePassword(body: ChangePasswordRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/change-password`,
      body
    );
  }

  forgotPassword(body: ForgotPasswordRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/forgot-password`,
      body
    );
  }

  resetPassword(body: ResetPasswordRequest | undefined): Observable<any> {
    return this.http.post(
      `${this.url}/reset-password`,
      body
    );
  }

  employeeRegister(body: EmployeeRegistrationRequest): Observable<any> {
    return this.http.post(`${this.url}/apply`, body);
  }

  // Admin approval / rejection for employee applications as requested
  getPendingEmployeeRequests(): Observable<any[]> {
    return this.http.get<any[]>(`${this.adminUrl}/pending-requests`);
  }

  approveEmployeeRequest(requestId: string): Observable<any> {
    return this.http.post(`${this.adminUrl}/approve/${requestId}`, {});
  }

  rejectEmployeeRequest(requestId: string): Observable<any> {
    return this.http.post(`${this.adminUrl}/reject/${requestId}`, {});
  }

  // Helper method to set demo or active session role
  setRole(role: UserRole, user?: { email: string; name: string }): void {
    this.currentRole.set(role);
    this.currentUser.set({
      email: user?.email || `${role.toLowerCase()}@evsure.com`,
      name: user?.name || role,
      role
    });
  }

  isLoggedIn(): boolean {
    return this.currentUser() !== null;
  }
}
