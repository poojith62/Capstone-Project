import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BatteryResponse } from '../Models/Vehicle/battery/battery-response.model';
import { UpdateBatteryRequest } from '../Models/Vehicle/battery/update-battery-request.model';

@Injectable({
  providedIn: 'root'
})
export class BatteryService {
  private readonly url = '/api/vehicles';

  constructor(private http: HttpClient) {}

  get(vehicleId: string): Observable<BatteryResponse> {
    return this.http.get<BatteryResponse>(
      `${this.url}/${vehicleId}/battery`
    );
  }

  update(
    vehicleId: string,
    request: UpdateBatteryRequest
  ): Observable<BatteryResponse> {
    return this.http.put<BatteryResponse>(
      `${this.url}/${vehicleId}/battery`,
      request
    );
  }
}
