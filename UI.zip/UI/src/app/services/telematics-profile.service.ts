import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TelematicsProfileResponse } from '../Models/Vehicle/TelematicsProfile/telematics-profile-response.model';
import { environment } from '../../environment/environment';
import { UpdateTelematicsProfileRequest } from '../Models/Vehicle/TelematicsProfile/update-telematics-profile-request.model';

@Injectable({
  providedIn: 'root'
})
export class TelematicsProfileService {
  private url = environment.apiUrl + '/api/vehicles';

  constructor(private http: HttpClient) {}

  get(vehicleId: string): Observable<TelematicsProfileResponse> {
    return this.http.get<TelematicsProfileResponse>(
      `${this.url}/${vehicleId}/telematics-profile`
    );
  }

  update(
    vehicleId: string,
    body: UpdateTelematicsProfileRequest
  ): Observable<TelematicsProfileResponse> {
    return this.http.put<TelematicsProfileResponse>(
      `${this.url}/${vehicleId}/telematics-profile`,
      body
    );
  }
}
