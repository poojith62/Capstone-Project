import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreatePolicyRequest } from '../Models/Policy/create-policy-request.model';
import { PolicyResponse } from '../Models/Policy/policy-response.model';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private readonly url = '/api/policies';

  constructor(private http: HttpClient) {}

  issuePolicy(request: CreatePolicyRequest): Observable<PolicyResponse> {
    return this.http.post<PolicyResponse>(
      this.url,
      request
    );
  }

  getCustomerPolicies(customerId: string): Observable<PolicyResponse[]> {
    return this.http.get<PolicyResponse[]>(
      `${this.url}/customer/${customerId}`
    );
  }

  getPolicy(policyId: string): Observable<PolicyResponse> {
    return this.http.get<PolicyResponse>(
      `${this.url}/${policyId}`
    );
  }
}
