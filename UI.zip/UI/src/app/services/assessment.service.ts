import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';
import { CreateAssessmentRequest } from '../Models/Claims/claim-assessment-request.model';
import { PaymentResponse } from '../Models/Claims/payment-response.model';

@Injectable({
  providedIn: 'root'
})
export class AssessmentService {
  private url = environment.apiUrl + '/api/claims';

  constructor(private http: HttpClient) {}

  assessClaim(
    claimId: string,
    body: CreateAssessmentRequest
  ): Observable<PaymentResponse> {
    return this.http.post<PaymentResponse>(
      `${this.url}/${claimId}/assessment`,
      body
    );
  }
}
