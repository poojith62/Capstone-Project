import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';
import { CreateVehicleRequest } from '../Models/Vehicle/vehicles/create-vehicle-request.model';
import { VehicleResponse } from '../Models/Vehicle/vehicles/vehicle-response.model';
import { UpdateVehicleRequest } from '../Models/Vehicle/vehicles/update-vehicle-request.model';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private url = environment.apiUrl;

  constructor(private http: HttpClient) {}

  create(
    customerId: string,
    body: CreateVehicleRequest
  ): Observable<VehicleResponse> {
    return this.http.post<VehicleResponse>(
      `${this.url}/api/customers/${customerId}/vehicles`,
      body
    );
  }

  getCustomerVehicles(
    customerId: string
  ): Observable<VehicleResponse[]> {
    return this.http.get<VehicleResponse[]>(
      `${this.url}/api/customers/${customerId}/vehicles`
    );
  }

  getVehicle(
    vehicleId: string
  ): Observable<VehicleResponse> {
    return this.http.get<VehicleResponse>(
      `${this.url}/api/vehicles/${vehicleId}`
    );
  }

  update(
    vehicleId: string,
    body: UpdateVehicleRequest
  ): Observable<VehicleResponse> {
    return this.http.put<VehicleResponse>(
      `${this.url}/api/vehicles/${vehicleId}`,
      body
    );
  }

  delete(
    vehicleId: string
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.url}/api/vehicles/${vehicleId}`
    );
  }
}
