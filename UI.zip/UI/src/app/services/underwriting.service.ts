import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UnderwritingCaseResponse } from '../Models/Underwriter/underwriter-case-response.model';
import { ApproveQuoteRequest } from '../Models/Underwriter/approve-quote-request.model';
import { RejectQuoteRequest } from '../Models/Underwriter/reject-quote-request.model';
import { ApplyLoadingRequest } from '../Models/Underwriter/apply-loading-request.model';

@Injectable({
  providedIn: 'root'
})
export class UnderwritingService {
  private readonly url = '/api/underwriting';

  constructor(private http: HttpClient) {}

  getPending(): Observable<UnderwritingCaseResponse[]> {
    return this.http.get<UnderwritingCaseResponse[]>(
      `${this.url}/pending`
    );
  }

  approve(
    caseId: string,
    request: ApproveQuoteRequest
  ): Observable<void> {
    return this.http.post<void>(
      `${this.url}/${caseId}/approve`,
      request
    );
  }

  reject(
    caseId: string,
    request: RejectQuoteRequest
  ): Observable<void> {
    return this.http.post<void>(
      `${this.url}/${caseId}/reject`,
      request
    );
  }

  applyLoading(
    caseId: string,
    request: ApplyLoadingRequest
  ): Observable<void> {
    return this.http.post<void>(
      `${this.url}/${caseId}/apply-loading`,
      request
    );
  }
}
