import { Component, inject } from '@angular/core';
import { ToastService } from '../services/toast.service';
@Component({ selector: 'app-toast', template: `@if (toast.toast(); as item) { <div class="fixed bottom-5 right-5 z-50 max-w-sm rounded-lg border-l-4 px-4 py-3 text-sm text-white shadow-lg" [class.bg-red-800]="item.type==='error'" [class.bg-stone-900]="item.type==='success'">{{item.message}}</div> }` })
export class ToastComponent {
    toast = inject(ToastService);
}
