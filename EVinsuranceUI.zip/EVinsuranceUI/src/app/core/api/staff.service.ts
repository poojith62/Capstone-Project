import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({ providedIn: 'root' })
export class StaffService {
    private http = inject(HttpClient);
    underwriterCases() { return this.http.get<unknown[]>(environment.apiUrl + '/underwriting/pending'); }
    decide(id: string, action: 'approve' | 'reject' | 'apply-loading' | 'request-documents', body = {}) { return this.http.post(`${environment.apiUrl}/underwriting/${id}/${action}`, body); }
    applications() { return this.http.get<unknown[]>(environment.apiUrl + '/admin/pending-requests'); }
    application(body: unknown) { return this.http.post(environment.apiUrl + '/employee/apply', body); }
    employeeDecision(id: string, action: 'approve' | 'reject') { return this.http.post(`${environment.apiUrl}/admin/${action}/${id}`, {}); }
}
