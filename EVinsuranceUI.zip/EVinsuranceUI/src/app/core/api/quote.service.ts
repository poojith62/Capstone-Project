import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({ providedIn: 'root' })
export class QuoteService {
    private http = inject(HttpClient);
    private url = environment.apiUrl + '/quotes';
    create(body: unknown) { return this.http.post(this.url, body); }
    customer(id: string) { return this.http.get<unknown[]>(`${this.url}/customer/${id}`); }
    get(id: string) { return this.http.get(`${this.url}/${id}`); }
}
