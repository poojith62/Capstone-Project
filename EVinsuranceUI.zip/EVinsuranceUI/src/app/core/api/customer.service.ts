import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
export interface Customer {
    id: string;
    fullName: string;
    email: string;
    phone?: string;
}
@Injectable({ providedIn: 'root' })
export class CustomerService {
    private http = inject(HttpClient);
    private url = environment.apiUrl + '/customers';
    me() { return this.http.get<Customer>(this.url + '/me'); }
    get(id: string) { return this.http.get<Customer>(`${this.url}/${id}`); }
    update(id: string, body: Partial<Customer>) { return this.http.put<Customer>(`${this.url}/${id}`, body); }
    addresses(id: string) { return this.http.get<unknown[]>(`${this.url}/${id}/addresses`); }
    documents(id: string) { return this.http.get<unknown[]>(`${this.url}/${id}/documents`); }
}
