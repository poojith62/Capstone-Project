import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({ providedIn: 'root' })
export class ClaimService {
    private http = inject(HttpClient);
    private url = environment.apiUrl + '/claims';
    create(body: unknown) { return this.http.post(this.url, body); }
    customer(id: string) { return this.http.get<unknown[]>(`${this.url}/customer/${id}`); }
    pending() { return this.http.get<unknown[]>(this.url + '/pending'); }
    assess(id: string, body: unknown) { return this.http.post(`${this.url}/${id}/assessment`, body); }
}
