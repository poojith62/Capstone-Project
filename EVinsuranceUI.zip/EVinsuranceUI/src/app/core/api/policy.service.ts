import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({ providedIn: 'root' })
export class PolicyService {
    private http = inject(HttpClient);
    private url = environment.apiUrl + '/policies';
    create(body: unknown) { return this.http.post(this.url, body); }
    customer(id: string) { return this.http.get<unknown[]>(`${this.url}/customer/${id}`); }
    renew(body: unknown) { return this.http.post(environment.apiUrl + '/renewals', body); }
}
