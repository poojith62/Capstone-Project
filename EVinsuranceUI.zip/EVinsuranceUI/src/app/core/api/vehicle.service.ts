import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
export interface Vehicle {
    id: string;
    make: string;
    model: string;
    registrationNumber: string;
    year: number;
    value: number;
}
@Injectable({ providedIn: 'root' })
export class VehicleService {
    private http = inject(HttpClient);
    private url = environment.apiUrl;
    list(customerId: string) { return this.http.get<Vehicle[]>(`${this.url}/customers/${customerId}/vehicles`); }
    create(customerId: string, body: Partial<Vehicle>) { return this.http.post<Vehicle>(`${this.url}/customers/${customerId}/vehicles`, body); }
    get(id: string) { return this.http.get<Vehicle>(`${this.url}/vehicles/${id}`); }
    update(id: string, body: Partial<Vehicle>) { return this.http.put<Vehicle>(`${this.url}/vehicles/${id}`, body); }
    profile(id: string, type: 'battery' | 'charging-profile' | 'ev-profile' | 'telematics-profile') { return this.http.get<unknown>(`${this.url}/vehicles/${id}/${type}`); }
}
