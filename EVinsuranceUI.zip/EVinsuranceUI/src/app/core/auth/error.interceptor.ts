import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { ToastService } from '../../shared/services/toast.service';

/** Converts server failures into one consistent message for the user. */
export const errorInterceptor: HttpInterceptorFn = (request, next) =>
  next(request).pipe(
    catchError((error) => {
      const message = error.status === 0
        ? 'Cannot reach the EVSure API.'
        : (error.error?.message ?? `Request failed (${error.status}).`);

      inject(ToastService).show(message, 'error');
      return throwError(() => error);
    }),
  );
