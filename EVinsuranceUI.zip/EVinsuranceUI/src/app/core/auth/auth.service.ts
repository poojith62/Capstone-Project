import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';

import { environment } from '../../../environments/environment';
import { Role, TokenStorage } from './token.storage';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken?: string;
}

/** Owns authentication requests and the application's post-login navigation. */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly tokenStorage = inject(TokenStorage);
  private readonly router = inject(Router);
  private readonly authUrl = `${environment.apiUrl}/Auth`;

  login(credentials: LoginRequest) {
    return this.http
      .post<AuthResponse>(`${this.authUrl}/login`, credentials)
      .pipe(tap((response) => this.tokenStorage.set(response.accessToken, response.refreshToken)));
  }

  register(request: unknown) {
    return this.http.post(`${this.authUrl}/register`, request);
  }

  forgotPassword(request: unknown) {
    return this.http.post(`${this.authUrl}/forgot-password`, request);
  }

  currentRole(): Role | undefined {
    return this.tokenStorage.role();
  }

  /** Sends every user to their only permitted starting page. */
  redirectForRole(role: Role | undefined) {
    const homeByRole: Record<Role, string> = {
      Customer: '/customer/dashboard',
      Underwriter: '/underwriter/cases',
      Surveyor: '/surveyor/claims',
      Admin: '/admin/requests',
    };

    return this.router.navigateByUrl(role ? homeByRole[role] : '/login');
  }

  logout() {
    // A failed logout call must not leave local credentials available.
    this.http.post(`${this.authUrl}/logout`, {}).subscribe({ error: () => undefined });
    this.tokenStorage.clear();
    return this.router.navigateByUrl('/');
  }
}
