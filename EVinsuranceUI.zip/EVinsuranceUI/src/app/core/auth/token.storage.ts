import { Injectable } from '@angular/core';
export type Role = 'Customer' | 'Underwriter' | 'Surveyor' | 'Admin';
interface Claims {
    exp?: number;
    role?: Role;
    'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'?: Role;
    'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'?: string;
}
@Injectable({ providedIn: 'root' })
export class TokenStorage {
    private readonly accessKey = 'evsure_access_token';
    private readonly refreshKey = 'evsure_refresh_token';
    accessToken() { return localStorage.getItem(this.accessKey); }
    refreshToken() { return localStorage.getItem(this.refreshKey); }
    set(access: string, refresh?: string) { localStorage.setItem(this.accessKey, access); if (refresh)
        localStorage.setItem(this.refreshKey, refresh); }
    clear() { localStorage.removeItem(this.accessKey); localStorage.removeItem(this.refreshKey); }
    claims(): Claims | null { const token = this.accessToken(); if (!token)
        return null; try {
        return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))) as Claims;
    }
    catch {
        return null;
    } }
    role(): Role | undefined { const c = this.claims(); return c?.role ?? c?.['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']; }
    userId() { return this.claims()?.['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier']; }
    valid() { const exp = this.claims()?.exp; return !!exp && exp * 1000 > Date.now(); }
}
