import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { TokenStorage } from './token.storage';
export const authInterceptor: HttpInterceptorFn = (req, next) => { const token = inject(TokenStorage).accessToken(); const publicApi = /\/Auth\/(login|register|forgot-password|reset-password|refresh-token)/.test(req.url); return next(token && !publicApi ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req); };
