import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { TokenStorage } from './token.storage';

/** Blocks protected pages when no non-expired access token is stored. */
export const authGuard: CanActivateFn = () => {
  const tokenStorage = inject(TokenStorage);
  return tokenStorage.valid() ? true : inject(Router).createUrlTree(['/login']);
};
