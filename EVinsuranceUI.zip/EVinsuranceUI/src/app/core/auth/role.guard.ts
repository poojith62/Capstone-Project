import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router } from '@angular/router';
import { TokenStorage, Role } from './token.storage';
const homes: Record<Role, string> = { Customer: '/customer/dashboard', Underwriter: '/underwriter/cases', Surveyor: '/surveyor/claims', Admin: '/admin/requests' };
export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => { const role = inject(TokenStorage).role(); const allowed = route.data['roles'] as Role[]; return role && allowed.includes(role) ? true : inject(Router).createUrlTree([role ? homes[role] : '/login']); };
