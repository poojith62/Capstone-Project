import { Component, computed, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/auth/auth.service';
import { Role, TokenStorage } from '../core/auth/token.storage';
type Link = {
    label: string;
    path: string;
};
const links: Record<Role, Link[]> = { Customer: [{ label: 'Dashboard', path: '/customer/dashboard' }, { label: 'Vehicles', path: '/customer/vehicles' }, { label: 'Quotes', path: '/customer/quotes' }, { label: 'Policies', path: '/customer/policies' }, { label: 'Claims', path: '/customer/claims' }, { label: 'Profile', path: '/customer/profile' }], Underwriter: [{ label: 'Cases', path: '/underwriter/cases' }], Surveyor: [{ label: 'Claims queue', path: '/surveyor/claims' }], Admin: [{ label: 'Employee requests', path: '/admin/requests' }] };
@Component({ standalone: true, imports: [RouterLink, RouterLinkActive, RouterOutlet], template: `<div class="min-h-screen bg-warm/30"><aside class="fixed inset-y-0 z-20 flex w-60 flex-col bg-claret p-3 text-white" [class.-translate-x-full]="!open()"><a routerLink="/" class="px-3 py-4 font-[family-name:var(--font-family-display)] text-2xl">EV<span class="text-fuchsia">Sure</span></a><nav class="flex-1 space-y-1">@for(item of menu();track item.path){<a [routerLink]="item.path" routerLinkActive="bg-white !text-claret" class="block rounded-lg px-3 py-2.5 text-sm hover:bg-white/10" (click)="open.set(false)">{{item.label}}</a>}</nav><button class="px-3 py-2 text-left text-sm" (click)="auth.logout()">⎋ Logout</button></aside><div class="md:ml-60"><header class="flex h-14 items-center border-b border-warm bg-white px-4"><button class="md:hidden" (click)="open.set(!open())">☰</button><span class="badge ml-auto bg-[#f6ecf1] text-claret">{{role()}}</span></header><main class="mx-auto max-w-6xl p-4 md:p-8"><router-outlet /></main></div></div>` })
export class AppLayoutComponent {
    auth = inject(AuthService);
    private store = inject(TokenStorage);
    open = signal(false);
    role = computed(() => this.store.role() ?? '');
    menu = computed(() => links[this.store.role() ?? 'Customer']);
}
