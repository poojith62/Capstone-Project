import { Routes } from '@angular/router';

import { authGuard } from './core/auth/auth.guard';
import { roleGuard } from './core/auth/role.guard';

/**
 * Feature screens are lazy loaded so the public landing page remains small.
 * The layout owns the persistent navigation; child routes own page content.
 */
export const routes: Routes = [
  { path: '', loadComponent: () => import('./features/home/home-page/home-page').then((m) => m.HomePage) },
  { path: 'login', loadComponent: () => import('./features/auth/auth-page.component').then((m) => m.AuthPageComponent), data: { mode: 'login' } },
  { path: 'register', loadComponent: () => import('./features/auth/auth-page.component').then((m) => m.AuthPageComponent), data: { mode: 'register' } },
  { path: 'forgot-password', loadComponent: () => import('./features/auth/auth-page.component').then((m) => m.AuthPageComponent), data: { mode: 'forgot' } },
  { path: 'employee/apply', loadComponent: () => import('./features/auth/auth-page.component').then((m) => m.AuthPageComponent), data: { mode: 'apply' } },
  {
    path: 'customer',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['Customer'] },
    loadComponent: () => import('./layouts/app-layout.component').then((m) => m.AppLayoutComponent),
    children: [
      { path: 'dashboard', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'dashboard' } },
      { path: 'vehicles', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'vehicles' } },
      { path: 'quotes', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'quotes' } },
      { path: 'policies', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'policies' } },
      { path: 'claims', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'claims' } },
      { path: 'profile', loadComponent: () => import('./features/customer/customer-page.component').then((m) => m.CustomerPageComponent), data: { page: 'profile' } },
    ],
  },
  {
    path: 'underwriter', canActivate: [authGuard, roleGuard], data: { roles: ['Underwriter'] },
    loadComponent: () => import('./layouts/app-layout.component').then((m) => m.AppLayoutComponent),
    children: [{ path: 'cases', loadComponent: () => import('./features/staff/staff-page.component').then((m) => m.StaffPageComponent), data: { page: 'cases' } }],
  },
  {
    path: 'surveyor', canActivate: [authGuard, roleGuard], data: { roles: ['Surveyor'] },
    loadComponent: () => import('./layouts/app-layout.component').then((m) => m.AppLayoutComponent),
    children: [{ path: 'claims', loadComponent: () => import('./features/staff/staff-page.component').then((m) => m.StaffPageComponent), data: { page: 'surveyor' } }],
  },
  {
    path: 'admin', canActivate: [authGuard, roleGuard], data: { roles: ['Admin'] },
    loadComponent: () => import('./layouts/app-layout.component').then((m) => m.AppLayoutComponent),
    children: [{ path: 'requests', loadComponent: () => import('./features/staff/staff-page.component').then((m) => m.StaffPageComponent), data: { page: 'admin' } }],
  },
  { path: '**', redirectTo: '' },
];
