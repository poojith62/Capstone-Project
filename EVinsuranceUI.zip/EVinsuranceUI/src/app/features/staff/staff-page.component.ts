import { Component, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StaffService } from '../../core/api/staff.service';
import { ClaimService } from '../../core/api/claim.service';
import { ToastService } from '../../shared/services/toast.service';
@Component({ standalone: true, template: `<h1 class="font-[family-name:var(--font-family-display)] text-3xl">{{title}}</h1><section class="card mt-6">@for(item of items();track $index){<div class="flex flex-wrap items-center justify-between gap-3 border-b border-warm py-3"><span>{{item['id'] ?? item['name'] ?? item['fullName'] ?? 'Pending request'}}</span><div class="flex gap-2"><button class="btn" (click)="approve(item['id'])">Approve</button><button class="btn-secondary" (click)="reject(item['id'])">Reject</button></div></div>}@empty{<p class="text-sm text-stone-500">No items pending.</p>}</section>` })
export class StaffPageComponent implements OnInit {
    private route = inject(ActivatedRoute);
    private staff = inject(StaffService);
    private claims = inject(ClaimService);
    private toast = inject(ToastService);
    page = this.route.snapshot.data['page'] as string;
    items = signal<Record<string, unknown>[]>([]);
    get title() { return this.page === 'cases' ? 'Underwriting cases' : this.page === 'surveyor' ? 'Claims to assess' : 'Employee requests'; }
    ngOnInit() { (this.page === 'cases' ? this.staff.underwriterCases() : this.page === 'surveyor' ? this.claims.pending() : this.staff.applications()).subscribe({ next: x => this.items.set(x as Record<string, unknown>[]) }); }
    approve(id: unknown) { if (!id)
        return; const req = this.page === 'cases' ? this.staff.decide(String(id), 'approve') : this.page === 'surveyor' ? this.claims.assess(String(id), { decision: 'Approved' }) : this.staff.employeeDecision(String(id), 'approve'); req.subscribe({ next: () => this.toast.show('Approved.') }); }
    reject(id: unknown) { if (!id)
        return; const req = this.page === 'cases' ? this.staff.decide(String(id), 'reject') : this.page === 'surveyor' ? this.claims.assess(String(id), { decision: 'Rejected' }) : this.staff.employeeDecision(String(id), 'reject'); req.subscribe({ next: () => this.toast.show('Rejected.') }); }
}
