import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Hero } from '../hero/hero';
import { CoverageGrid } from '../coverage-grid/coverage-grid';
import { HowItWorks } from '../how-it-works/how-it-works';
@Component({
    selector: 'app-home-page',
    imports: [RouterLink, Hero, CoverageGrid, HowItWorks],
    templateUrl: './home-page.html',
    styleUrl: './home-page.css',
})
export class HomePage {
}
