import { Component } from '@angular/core';
@Component({
    selector: 'app-coverage-grid',
    imports: [],
    templateUrl: './coverage-grid.html',
    styleUrl: './coverage-grid.css',
})
export class CoverageGrid {
    readonly products = [{ icon: '⚡', name: 'Electric vehicle', copy: 'Battery-aware cover for the way you drive.', available: true }, { icon: '♥', name: 'Health', copy: 'Hospital and wellness cover for your family.', available: false }, { icon: '⌂', name: 'Home', copy: 'Protection for your home and belongings.', available: false }, { icon: '✈', name: 'Travel', copy: 'Confident cover wherever you go.', available: false }, { icon: '◈', name: 'Life', copy: 'Long-term security for the people you love.', available: false }, { icon: '▣', name: 'Business', copy: 'Cover for fleets, shops and offices.', available: false }];
}
