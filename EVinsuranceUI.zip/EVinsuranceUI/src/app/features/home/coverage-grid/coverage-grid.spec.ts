import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CoverageGrid } from './coverage-grid';
describe('CoverageGrid', () => {
    let component: CoverageGrid;
    let fixture: ComponentFixture<CoverageGrid>;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [CoverageGrid]
        })
            .compileComponents();
        fixture = TestBed.createComponent(CoverageGrid);
        component = fixture.componentInstance;
        await fixture.whenStable();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
