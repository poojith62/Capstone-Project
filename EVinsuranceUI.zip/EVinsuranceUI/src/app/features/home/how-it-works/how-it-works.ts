import { Component } from '@angular/core';
@Component({
    selector: 'app-how-it-works',
    imports: [],
    templateUrl: './how-it-works.html',
    styleUrl: './how-it-works.css',
})
export class HowItWorks {
    readonly steps = [{ number: '01', title: 'Tell us about your EV', copy: 'Add your vehicle and preferred cover in a few simple fields.' }, { number: '02', title: 'See a tailored quote', copy: 'We account for relevant EV details, including battery health.' }, { number: '03', title: 'Get expert approval', copy: 'Our underwriting team reviews your case with clear status updates.' }, { number: '04', title: 'Manage everything online', copy: 'Track your policy, renewals, documents and claims in one place.' }];
}
