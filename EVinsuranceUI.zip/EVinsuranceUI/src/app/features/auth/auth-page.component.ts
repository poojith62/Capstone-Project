import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../core/auth/auth.service';
import { StaffService } from '../../core/api/staff.service';
import { ToastService } from '../../shared/services/toast.service';
@Component({ standalone: true, imports: [RouterLink, ReactiveFormsModule], template: `<div class="grid min-h-screen md:grid-cols-2"><aside class="hidden flex-col justify-between bg-claret p-12 text-white md:flex"><a routerLink="/" class="font-[family-name:var(--font-family-display)] text-3xl">EV<span class="text-fuchsia">Sure</span></a><h1 class="font-[family-name:var(--font-family-display)] text-4xl">Insurance that keeps up with you.</h1></aside><main class="flex items-center justify-center p-6"><section class="w-full max-w-sm"><a routerLink="/" class="text-xs text-claret">← Back to home</a><h2 class="mt-4 font-[family-name:var(--font-family-display)] text-3xl">{{title}}</h2><form class="mt-6 space-y-4" [formGroup]="form" (ngSubmit)="submit()">@if(mode==='register'||mode==='apply'){<div><label class="label">Full name</label><input class="field" formControlName="fullName"></div>}<div><label class="label">Email</label><input class="field" formControlName="email" type="email"></div>@if(mode==='login'||mode==='register'){<div><label class="label">Password</label><input class="field" formControlName="password" type="password"></div>}@if(mode==='apply'){<div><label class="label">Role</label><select class="field" formControlName="role"><option>Underwriter</option><option>Surveyor</option></select></div>}<button class="btn w-full" [disabled]="form.invalid||busy">{{button}}</button></form><p class="mt-5 text-center text-sm text-stone-500">@if(mode==='login'){<a routerLink="/register" class="text-claret">Create an account</a> · <a routerLink="/forgot-password" class="text-claret">Forgot password?</a>}@else{<a routerLink="/login" class="text-claret">Back to login</a>}</p></section></main></div>` })
export class AuthPageComponent {
    private route = inject(ActivatedRoute);
    private fb = inject(FormBuilder);
    private auth = inject(AuthService);
    private staff = inject(StaffService);
    private toast = inject(ToastService);
    mode = (this.route.snapshot.data['mode'] as string) || 'login';
    busy = false;
    form = this.fb.group({ fullName: [''], email: ['', [Validators.required, Validators.email]], password: [''], role: ['Underwriter'] });
    get title() { return this.mode === 'login' ? 'Welcome back' : this.mode === 'register' ? 'Create your account' : this.mode === 'apply' ? 'Employee application' : 'Reset password'; }
    get button() { return this.mode === 'login' ? 'Sign in' : this.mode === 'register' ? 'Register' : this.mode === 'apply' ? 'Submit for approval' : 'Send reset link'; }
    submit() { if (this.form.invalid)
        return; this.busy = true; const data = this.form.getRawValue(); const done = (message: string) => { this.busy = false; this.toast.show(message); }; if (this.mode === 'login') {
        this.auth.login({ email: data.email ?? '', password: data.password ?? '' }).subscribe({ next: () => this.auth.redirectForRole(this.auth.currentRole()), error: () => this.busy = false });
        return;
    } if (this.mode === 'apply') {
        this.staff.application(data).subscribe({ next: () => done('Application submitted.'), error: () => this.busy = false });
        return;
    } if (this.mode === 'register') {
        this.auth.register(data).subscribe({ next: () => done('Account created. Please sign in.'), error: () => this.busy = false });
        return;
    } this.auth.forgotPassword({ email: data.email }).subscribe({ next: () => done('Reset link requested.'), error: () => this.busy = false }); }
}
