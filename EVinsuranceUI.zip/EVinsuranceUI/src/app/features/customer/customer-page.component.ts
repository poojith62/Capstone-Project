import { Component, inject, OnInit, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CurrencyPipe, TitleCasePipe } from '@angular/common';
import { TokenStorage } from '../../core/auth/token.storage';
import { Vehicle, VehicleService } from '../../core/api/vehicle.service';
@Component({ standalone: true, imports: [CurrencyPipe, TitleCasePipe], template: `
@if(page==='dashboard'){<h1 class="font-[family-name:var(--font-family-display)] text-3xl">Dashboard</h1><div class="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">@for(k of kpis;track k.label){<div class="card"><p class="label">{{k.label}}</p><p class="font-[family-name:var(--font-family-display)] text-3xl">{{k.value}}</p></div>}</div>}
@else if(page==='vehicles'){<div class="flex justify-between"><h1 class="font-[family-name:var(--font-family-display)] text-3xl">Vehicles</h1><button class="btn">+ Add vehicle</button></div><div class="mt-6 grid gap-4 lg:grid-cols-3"><div class="card text-center"><p class="label">Battery health</p><p class="mt-5 text-4xl text-claret">84%</p><p class="mt-3 text-sm text-stone-500">Latest battery health record</p></div><div class="card lg:col-span-2">@for(v of vehicles();track v.id){<div class="grid grid-cols-2 gap-4 text-sm"><div><p class="label">Model</p>{{v.make}} {{v.model}}</div><div><p class="label">Registration</p>{{v.registrationNumber}}</div><div><p class="label">Year</p>{{v.year}}</div><div><p class="label">Value</p>{{v.value|currency:'INR':'symbol':'1.0-0'}}</div></div>}@empty{<p class="text-stone-500">No vehicles yet.</p>}</div></div>}
@else {<h1 class="font-[family-name:var(--font-family-display)] text-3xl">{{page|titlecase}}</h1><div class="card mt-6 text-stone-500">This feature is routed and ready to bind to its typed backend service.</div>}` })
export class CustomerPageComponent implements OnInit {
    private route = inject(ActivatedRoute);
    private tokens = inject(TokenStorage);
    private vehiclesApi = inject(VehicleService);
    page = this.route.snapshot.data['page'] as string;
    vehicles = signal<Vehicle[]>([]);
    kpis = [{ label: 'Vehicles', value: '2' }, { label: 'Active policies', value: '1' }, { label: 'Open claims', value: '1' }, { label: 'Pending quotes', value: '2' }];
    ngOnInit() { if (this.page === 'vehicles') {
        const id = this.tokens.userId();
        if (id)
            this.vehiclesApi.list(id).subscribe({ next: v => this.vehicles.set(v) });
    } }
}
