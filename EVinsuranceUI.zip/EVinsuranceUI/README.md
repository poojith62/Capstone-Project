# EVSure Angular UI

This project implements the supplied EVSure UI plan with Angular standalone components, Tailwind CSS, typed API services, JWT storage, role guards, and protected role-based routes. DaisyUI is deliberately not included.

## Run on the company laptop

1. Copy this project into the Angular workspace.
2. Install only the package versions in `package.json` (or use the existing matching `node_modules`).
3. Set `src/environments/environment.ts` to the backend URL if it differs.
4. Run `npm start` and open `http://localhost:4200`.

The API must allow CORS from `http://localhost:4200` and trust the local HTTPS certificate for `https://localhost:7273`.

## Backend fields to confirm

The plan correctly calls out that quote, policy, claim, and underwriting response field names need confirmation. Once confirmed, bind those fields in the feature tables/forms; the endpoint wrappers are already isolated in `src/app/core/api`.
